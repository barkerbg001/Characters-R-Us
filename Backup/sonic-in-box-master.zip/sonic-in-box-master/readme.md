# Sonic in Box

A Sonic Java 'Game' written in Java

- 241 sprites png

- JavaSE 1.8

> Threads...
> Observer...
> Observable...

Screen Capture
----
[![See on Youtube](https://github.com/frmichetti/sonic-in-box/blob/master/sonic.gif)](https://youtu.be/cw36vmkttKA?list=PLDzyDVZ4JbDjkNNXy164lkYRphAnbyA7K)

License
----

Not Implemented Yet!