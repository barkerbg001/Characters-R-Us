package br.com.codecode.sonicinbox;

import java.applet.Applet;

// TODO: Auto-generated Javadoc
/**
 * The Class MyApplet.
 */
public class MyApplet extends Applet {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8998700725003389219L;

    /* (non-Javadoc)
     * @see java.applet.Applet#init()
     */
    @Override
    public void init() {

	super.init();

	new Start();
    }

}
