package br.com.codecode.sonicinbox.interfaces;

// TODO: Auto-generated Javadoc
/**
 * The Interface Syncronizeable.
 */
public interface Syncronizeable {
   
    /** The fps. */
    int FPS = (1000 / 60);
}
