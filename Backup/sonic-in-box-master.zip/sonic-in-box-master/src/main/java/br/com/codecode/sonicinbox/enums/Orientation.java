package br.com.codecode.sonicinbox.enums;

// TODO: Auto-generated Javadoc
/**
 * Possible Orientations.
 *
 * @author felipe
 * @version 1.0
 * @since 1.0
 */
public enum Orientation {
    
    /** The right. */
    RIGHT, 
 /** The left. */
 LEFT;
}
