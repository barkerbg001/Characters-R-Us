/**
 * @author Felipe Rodrigues Michetti
 * @see <a href="http://portfolio-frmichetti.rhcloud.com">My Portfolio</a>
 * @see <a href="mailto:frmichetti@gmail.com">Mail Me frmichetti@gmail.com</a>
 * @since 1.1
 * @version 1.0
 */
package br.com.codecode.sonicinbox.interfaces;